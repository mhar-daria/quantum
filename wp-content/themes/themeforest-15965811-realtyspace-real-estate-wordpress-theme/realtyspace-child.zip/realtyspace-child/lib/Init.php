<?php

namespace cf47\theme\realtyspace\child;

use cf47\themecore\Application;
use cf47\themecore\ServiceProviderInterface;

class Init implements ServiceProviderInterface
{

    public function register(Application $app)
    {
        // Override services here

    }

    public function boot(Application $app)
    {
        // Boot your stuff here
    }
}